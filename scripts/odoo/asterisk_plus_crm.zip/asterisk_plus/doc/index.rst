===========================
Asterisk Plus Documentation
===========================
The **detailed changelog** is available here: http://feedback.odoopbx.com/changelog

You can find setup installation **instructions** at https://help.odoopbx.com

You can also submit a **bug report** here: http://feedback.odoopbx.com/bugs

Or you can **request a feature** here: http://feedback.odoopbx.com/features

For **commerical support** submit a ticket at https://odoopbx.com/helpdesk
