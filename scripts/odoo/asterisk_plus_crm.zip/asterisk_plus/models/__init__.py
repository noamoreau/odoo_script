from . import event
from . import call
from . import call_event
from . import channel
from . import recording
from . import res_groups
from . import res_users
from . import server
from . import settings
from . import user_channel
from . import user
from . import res_partner
from . import tag
from . import debug
# from . import compat # Used only to upgrade old installations.